﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FindDuplicatesInFiles
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Укажите пути к вашим файлам
            string filePath1 = "file1.txt";
            string filePath2 = "file2.txt";
            DoAll.DoAllStuff(filePath1, filePath2);

        }
    }
}
