﻿using System.Collections.Generic;
using System;
using System.IO;
using System.Linq;

namespace FindDuplicatesInFiles
{
    public class DoAll
    {
        public static void DoAllStuff(string path1, string path2)
        {
            // Чтение строк из файлов
            string[] lines1 = File.ReadAllLines(path1);
            string[] lines2 = File.ReadAllLines(path2);

            // Шаг 1: Создание словарей <индекс строки, длина строки>
            Dictionary<int, int> dict1 = new Dictionary<int, int>();
            Dictionary<int, int> dict2 = new Dictionary<int, int>();

            // Заполнение словарей
            for (int i = 0; i < lines1.Length; i++)
            {
                dict1[i] = lines1[i].Length;
            }

            for (int i = 0; i < lines2.Length; i++)
            {
                dict2[i] = lines2[i].Length;
            }

            // Шаг 3: Создание и сортировка массивов длин строк
            int[] lengths1 = dict1.Values.ToArray();
            int[] lengths2 = dict2.Values.ToArray();

            Array.Sort(lengths1);
            Array.Sort(lengths2);

            // Шаг 4: Поиск уникальных длин с помощью алгоритма двух указателей
            List<int> uniqueLengths = FindUniqueLengths(lengths1, lengths2);

            // Шаг 5: Удаление строк с уникальными длинами из словарей
            RemoveUniqueLengths(dict1, uniqueLengths);
            RemoveUniqueLengths(dict2, uniqueLengths);

            // Шаг 6: Находим и выводим все одинаковые строки
            var duplicates = FindDuplicateStrings(lines1, lines2, dict1, dict2);

            if (duplicates.Any())
            {
                Console.WriteLine("Найдены одинаковые строки:");
                foreach (var duplicate in duplicates)
                {
                    Console.WriteLine($"- {duplicate}");
                }
                Console.WriteLine($"Всего найдено {duplicates.Count} дубликатов.");
            }
            else
            {
                Console.WriteLine("Одинаковых строк не найдено.");
            }
        }

        // Новый метод для поиска и возврата всех дубликатов
        private static List<string> FindDuplicateStrings(string[] lines1, string[] lines2,
                                                       Dictionary<int, int> dict1, Dictionary<int, int> dict2)
        {
            var strings1 = dict1.Keys.Select(index => lines1[index]);
            var strings2 = dict2.Keys.Select(index => lines2[index]).ToHashSet();

            var duplicates = new List<string>();

            foreach (string str in strings1)
            {
                if (strings2.Contains(str))
                {
                    duplicates.Add(str);
                }
            }

            return duplicates;
        }

        // Метод для поиска уникальных длин в двух массивах
        static List<int> FindUniqueLengths(int[] lengths1, int[] lengths2)
        {
            List<int> uniqueLengths = new List<int>();
            int i = 0, j = 0;

            while (i < lengths1.Length && j < lengths2.Length)
            {
                if (lengths1[i] < lengths2[j])
                {
                    uniqueLengths.Add(lengths1[i]);
                    i++;
                }
                else if (lengths1[i] > lengths2[j])
                {
                    uniqueLengths.Add(lengths2[j]);
                    j++;
                }
                else
                {
                    i++;
                    j++;
                }
            }

            // Добавляем оставшиеся элементы из первого массива
            while (i < lengths1.Length)
            {
                uniqueLengths.Add(lengths1[i]);
                i++;
            }

            // Добавляем оставшиеся элементы из второго массива
            while (j < lengths2.Length)
            {
                uniqueLengths.Add(lengths2[j]);
                j++;
            }

            return uniqueLengths;
        }

        // Метод для удаления строк с уникальными длинами из словаря
        static void RemoveUniqueLengths(Dictionary<int, int> dict, List<int> uniqueLengths)
        {
            // Создаем список ключей для удаления
            List<int> keysToRemove = new List<int>();

            foreach (var pair in dict)
            {
                if (uniqueLengths.Contains(pair.Value))
                {
                    keysToRemove.Add(pair.Key);
                }
            }

            // Удаляем элементы по найденным ключам
            foreach (int key in keysToRemove)
            {
                dict.Remove(key);
            }
        }

        // Метод для сравнения строк с одинаковыми длинами
        static bool CompareStringsWithSameLengths(string[] lines1, string[] lines2,
                                                Dictionary<int, int> dict1, Dictionary<int, int> dict2)
        {
            // Собираем строки из первого файла, которые нужно сравнивать
            var strings1 = dict1.Keys.Select(index => lines1[index]);

            // Собираем строки из второго файла, которые нужно сравнивать
            var strings2 = dict2.Keys.Select(index => lines2[index]).ToHashSet();

            // Проверяем, есть ли пересечение между двумя наборами строк
            foreach (string str in strings1)
            {
                if (strings2.Contains(str))
                {
                    return true;
                }
            }
            return false;
        }
    }
}